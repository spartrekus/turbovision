/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if defined( Uses_TPoint )

#include <tv/point.h>

#endif

#if defined( Uses_TRect )

#include <tv/rect.h>

#endif

#if defined( Uses_TCollection )

#include <tv/collectn.h>

#endif

#if defined( Uses_TSortedCollection )

#include <tv/sortcoll.h>

#endif


