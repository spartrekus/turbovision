/*
  This file will be used by TV in future releases.
  I added it because the r2_0_1u cvs branch uses it and some code could have
it as dependencie.
*/
