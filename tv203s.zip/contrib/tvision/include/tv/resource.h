/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if defined( Uses_TStringCollection )

#include <tv/strncoll.h>

#endif

#if defined( Uses_TResourceItem )

#include <tv/resitem.h>

#endif

#if defined( Uses_TResourceCollection )

#include <tv/rescoll.h>

#endif

#if defined( Uses_TResourceFile )

#include <tv/resfile.h>

#endif

#if defined( Uses_TStrIndexRec )

#include <tv/strinrec.h>

#endif

#if defined( Uses_TStringList )

#include <tv/strilist.h>

#endif

#if defined( Uses_TStrListMaker )

#include <tv/strlistm.h>

#endif


