/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if defined( Uses_TBackground )

#include <backgrnd.h>

#endif


#if defined( Uses_TDeskTop )

#include <desktop.h>

#endif


#if defined( Uses_TProgram )

#include <program.h>

#endif

#if defined( Uses_TApplication )

#include <applictn.h>

#endif


