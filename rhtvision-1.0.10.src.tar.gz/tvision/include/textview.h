/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if defined( Uses_TTextDevice )

#include <textdev.h>

#endif

#if defined( Uses_TTerminal )

#include <terminal.h>

#endif

#if defined( Uses_otstream )

#include <otstream.h>

#endif


