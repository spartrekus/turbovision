/* Generated automatically by the configure script */

/* ncurses 4.2 or better have define_key */
#define HAVE_DEFINE_KEY

/* The X11 keysyms are there */
#define HAVE_KEYSYMS

/* International support with gettext */
#define HAVE_INTL_SUPPORT
