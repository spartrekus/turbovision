// See ../../include/screen.h for more information
unsigned TurboVision_screenOptions=0;
