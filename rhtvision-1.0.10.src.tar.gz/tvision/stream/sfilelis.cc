#define Uses_TFileList
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RFileList( TFileList::name,
                            TFileList::build,
                            __DELTA(TFileList)
                          );

