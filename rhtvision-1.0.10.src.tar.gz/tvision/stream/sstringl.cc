#define Uses_TStringList
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RStringList( TStringList::name,
                              TStringList::build,
                              __DELTA(TStringList)
                            );

