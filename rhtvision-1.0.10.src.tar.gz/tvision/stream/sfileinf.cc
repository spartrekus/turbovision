#define Uses_TFileInfoPane
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RFileInfoPane( TFileInfoPane::name,
                                TFileInfoPane::build,
                                __DELTA(TFileInfoPane)
                              );

