#define Uses_TFileCollection
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RFileCollection( TFileCollection::name,
                                  TFileCollection::build,
                                  __DELTA(TFileCollection)
                                );

