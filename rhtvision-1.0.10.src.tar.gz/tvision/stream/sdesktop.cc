#define Uses_TDeskTop
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RDeskTop( TDeskTop::name,
                           TDeskTop::build,
                           __DELTA(TDeskTop)
                         );

