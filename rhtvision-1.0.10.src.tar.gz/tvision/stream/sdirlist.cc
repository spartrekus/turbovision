#define Uses_TDirListBox
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RDirListBox( TDirListBox::name,
                              TDirListBox::build,
                              __DELTA(TDirListBox)
                            );

