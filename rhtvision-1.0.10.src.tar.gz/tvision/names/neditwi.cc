#define Uses_n
#include <ttypes.h>
#include <tvutil.h>
n(TEditWindow)

